
 module.js
-----------

 - answer swainet's questions
 - auto generate id / dependencies when building and combining

 - docs（参考 FlyScript 文档, data-main, prefix, 子模块, package,
 build 工具, jquery 插件, 时间戳, module.load）

 - compare module.js with BravoJS, FlyScript, RequireJS, YY etc.



 modules
---------
 - cookie


  related
----------
 - the relationship of SeaJS and KISSY
 - seajs/tools
 - seajs.com
