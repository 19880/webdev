
SeaJS is a javascript framework that makes it easy to build scalable web applications.

## Vision

The sea can hold the water from thousands of rivers, it's big because of its capacity.

## License

SeaJS is available under either the terms of the [MIT license](https://github.com/tannhu/jsface/blob/master/MIT-LICENSE.txt).

## Some more thing

Question, comments, feedbacks please go to [SeaJS Group](http://groups.google.com/group/seajs).
