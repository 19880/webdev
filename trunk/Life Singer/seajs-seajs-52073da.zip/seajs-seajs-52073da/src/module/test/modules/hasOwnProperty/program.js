module.declare(function(require) {

  var hasOwnProperty = require('./hasOwnProperty');
  var toString = require('./toString');
  var test = require('test/test');

  test.print('DONE', 'info');

});
