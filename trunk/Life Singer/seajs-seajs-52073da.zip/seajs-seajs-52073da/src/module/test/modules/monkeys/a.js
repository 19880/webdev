module.declare(function(require) {

  require('./program').monkey = 10;

});
