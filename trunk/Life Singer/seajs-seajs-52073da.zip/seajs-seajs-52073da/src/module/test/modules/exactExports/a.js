module.declare(function (require, exports) {

  exports.program = function () {
    return require('./program');
  };

});
