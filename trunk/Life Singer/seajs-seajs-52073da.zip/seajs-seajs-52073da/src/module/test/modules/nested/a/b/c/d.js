module.declare(function(require, exports) {

  exports.foo = function () {
    return 1;
  };

});
