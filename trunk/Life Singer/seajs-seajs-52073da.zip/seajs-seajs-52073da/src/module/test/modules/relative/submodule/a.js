module.declare(function(require, exports) {

  exports.foo = require('./b').foo;

});
