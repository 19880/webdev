module.declare(function(require, exports) {

  exports.foo = function () {
  };

});
