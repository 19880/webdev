module.declare(function(require, exports, module){

});

