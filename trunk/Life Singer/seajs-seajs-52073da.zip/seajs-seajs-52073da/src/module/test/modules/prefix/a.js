module.declare(function(require, exports) {

  exports.foo = 'a';

});
